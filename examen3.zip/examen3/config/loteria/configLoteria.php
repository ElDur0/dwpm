<?php
$debug = true;
$key = "12345";
$conexion = array(
    "servername"=>"localhost",
    "username"=> "Luis",
    "password"=>"peliculas",
    "dbname"=>"examen"
);
$datos = 'loteria/loteria.php';