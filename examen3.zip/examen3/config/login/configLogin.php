<?php
$debug = true;
$key = "12345";
$conexion = array(
    "servername"=>"localhost",
    "username"=> "Luis",
    "password"=>"peliculas",
    "dbname"=>"clase"
);
$datos = 'login/login.php';