<?php
$debug      = true;
$key        = "12345";
$datos      = "peliculas/peliculas.php";

$conexion = array(
    "servername" => "localhost",
    "username"   => "Luis",
    "password"   => "peliculas",
    "dbname"     => "clase"
);